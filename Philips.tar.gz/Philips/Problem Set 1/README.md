OSMP
====

Operating systems and multicore programming (1DT089)
